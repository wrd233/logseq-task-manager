#!/bin/sh
cd -- "$(dirname -- "$0")/dist" || exit 1
if ! command -v node >/dev/null 2>&1; then printf "协作需要 Node 20.19 或更高版本。基础阅读不需要 Node。\n"; exit 1; fi
exec node workspace.mjs workspace serve "$@"
